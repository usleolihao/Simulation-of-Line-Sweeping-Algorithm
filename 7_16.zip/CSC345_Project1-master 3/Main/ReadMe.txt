Hello!

I have included two code files and some example input files to help you get started.
If you have any questions feel free to stop by office hours or email me(jrafko@email.arizona.edu)!

Starter_Methods:

I decided to give you a file parser to save you a little time, if you feel like 
you want the array it should be a simple change to grab it to use for your
skiplast later on!

Are_Intersecting and Is_Above both use classes provided to you, if you have any
questions as to how these classes are setup feel free to analyze the code, it's not too complex.


Segment:

Segment contains basically the Segment and Point classes.



I would highly recommend reading both files carefully to familiarize yourself
with all the code to make the most out of your project!

Remember! When you're ready to submit the project submit it to the Project folder 
on the Gradescope: MX248K

Good Luck!
Jacob